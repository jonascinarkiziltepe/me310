# f(x) = x^3
# f'(x) = 3x^2

def fp(x):
    return 3*x*x
    #return 1/x
