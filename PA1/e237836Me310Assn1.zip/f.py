# f(x) = x^3
import math

def f(x):
    
    #return x*x*x
    #return math.log(x)
    return (math.cos(x) - pow(x,3))