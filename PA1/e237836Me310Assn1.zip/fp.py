# f(x) = x^3
# f'(x) = 3x^2
import math

def fp(x):
    #return 3*x*x
    #return 1/x
    return (-1) * math.sin(x) - 3*pow(x,2)
